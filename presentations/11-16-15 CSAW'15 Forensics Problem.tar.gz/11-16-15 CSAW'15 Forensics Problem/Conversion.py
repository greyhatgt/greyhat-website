import base64
import binascii
import sys

# The name of the file to read in and output file
fileName = sys.argv[1]
outFileName = "file"

# Read the file in, get rid of any new line characters
with open(fileName, "r") as myfile:
	data = myfile.read().replace('\n', '')

# Decode the string as base 64
data = base64.b64decode(data)

# Convert the base64 string to hex
data = data.encode("hex")

# Write the data to an output file
with open(outFileName, 'wb') as f:
	f.write(binascii.unhexlify(data))
